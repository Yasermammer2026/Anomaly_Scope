
# ******************************************************************************
# * @attention
# *
# * Copyright (c) 2022 STMicroelectronics.
# * All rights reserved.
# *
# * This software is licensed under terms that can be found in the LICENSE file
# * in the root directory of this software component.
# * If no LICENSE file comes with this software, it is provided AS-IS.
# *
# *
# ******************************************************************************
"""
PnPL Command Builders.

This module defines helpers for creating JSON-formatted PnPL messages. It exposes the
`PnPLCMDManager` class with static methods that build commands ready to be sent to a device,
and a minimal `PnPLCmdField` container that represents a (name, value) pair.

Overview:
- Returns strings produced by `json.dumps(...)` for transmission.
- Supports: get_presentation, get_identity (HSDatalog2 > v1.2.0), get_status (all/component),
    set_property (simple and nested), and component command messages.

Key Entities:
- `PnPLCMDManager`: Stateless factory of PnPL command strings.
- `PnPLCmdField`: Lightweight holder for a command field.

Design Notes:
- All builder methods are static and have no side effects.
- `create_set_property_cmd` accepts a `str` or `list[str]` to express nested paths.

Usage Example:
    >>> from stdatalog_pnpl.PnPLCmd import PnPLCMDManager
    >>> msg = PnPLCMDManager.create_get_device_status_cmd()
    >>> isinstance(msg, str)
    True
"""

import json

class PnPLCmdField:
    """
    Represents a field in a PnPL command with a name and value.
    Attributes:
        name (str): The name of the field.
        value (any): The value associated with the field.
    """
    name: str
    value: any

    def __init__(self):
        """
        Initialize a PnPLCmdField instance.
        """
        self.name
        self.value

class PnPLCMDManager:
    """
    Manages the creation of PnPL command messages in JSON format.
    Responsibilities:
        - Create various PnPL command messages such as Get Presentation,
            Get Identity, Get Device Status, Get Component Status, Set Property,
            and Command messages.
    Notes:
        - All methods are static for convenience; no instance state is kept.
    """
    def __init__(self):
        """
        Initialize the PnPL Command Manager.
        """
        pass

    # @staticmethod #OLD till HSDatalog2 v1.0.1
    # def create_get_presentation_string_cmd():
    #     message = {"system_info":""}
    #     return json.dumps(message)
    
    @staticmethod
    def create_get_presentation_string_cmd():
        """
        Create a PnPL Get Presentation message in JSON format.
        This message requests the presentation information of the device.
        It is always structured as:
            {
                "get_presentation": ""
            }
        Returns:
            str: JSON-formatted get presentation message structured as follows: 
            {
                "board_id": "<board_id>",
                "fw_id": "<fw_id>"
            }
        """
        message = {"get_presentation":""}
        return json.dumps(message)

    @staticmethod #Only for HSDatalog2 > v1.2.0
    def create_get_identity_string_cmd():
        """
        Create a PnPL Get Identity message in JSON format.
        This message requests the identity information of the device.
        Note: This message is only applicable for HSDatalog2 versions greater than v1.2.0.
        It is always structured as:
            {
                "get_identity": ""
            }
        Returns:
            str: JSON-formatted get presentation message structured as follows: 
            {
                "board_id": "<board_id>",
                "fw_id": "<fw_id>"
            }
        """
        message = {"get_identity":""}
        return json.dumps(message)

    @staticmethod
    def create_get_device_status_cmd():
        """
        Create a PnPL Get Device Status message in JSON format.
        This message requests the status of all components.
        It is always structured as:
            {
                "get_status": "all"
            }
        Returns:
            str: JSON-formatted get device status message.
        """
        message = {"get_status":"all"}
        return json.dumps(message)

    @staticmethod
    def create_get_component_status_cmd(comp_name: str):
        """
        Create a PnPL Get Component Status message in JSON format.
        Example:
            {
                "get_status": "component_name"
            }
        Parameters:
            comp_name: str
                Name of the component.
        Returns:
            str: JSON-formatted get component status message.
        """
        message = {"get_status": comp_name }
        return json.dumps(message)

    @staticmethod
    def create_set_property_cmd(comp_name, prop_name, prop_value):
        """
        Create a PnPL Set Property message in JSON format.
        The message structure varies based on whether prop_name is a string or a list.
        Examples:
        - Single property:
            {
                "component": {
                    "property_name": property_value
                }
        - Nested properties:
            {
                "component": {
                    "parent_property": {
                        "child_property": property_value
                    }
                }
        Parameters:
            comp_name: str
                Name of the component.
            prop_name: str or list[str]
                Name of the property to set. If a list, it represents a path of nested properties.
            prop_value:
                Value to assign to the property.
        Returns:
            str: JSON-formatted set property message.
        """
        if isinstance(prop_name, str):
            message = {
                comp_name: {
                    prop_name : prop_value
                }
            }
        else:
            # Create an empty dictionary
            mid_dict = {}
            # Loop through the list in reverse order
            for item in reversed(prop_name):
                # Create a new dictionary with the current item as the key
                new_dict = {item: mid_dict}
                # Update the main dictionary with the new dictionary
                mid_dict = new_dict

            # Loop through the keys and access the nested dictionary
            inner_dict = mid_dict
            for key in prop_name[:-1]:
                inner_dict = inner_dict[key]

            # Assign the new value to the inner key
            inner_dict[prop_name[-1]] = prop_value

            message = {
                comp_name: mid_dict
            }
        return json.dumps(message)

    @staticmethod
    def create_command_cmd(
        comp_name: str,
        command_name: str,
        req_name: str = None,
        req_value = None,
    ):
        """
        Create a PnPL Command message in JSON format.
        The message structure varies based on the presence of request name and value.
        Additional handling is included for dictionary-type request values
        (containing multiple key-value pairs).
        Examples:
        - No request name/value:
            {
                "component*command": ""
            }
        - With request name and value:
            {
                "component*command": {
                    "request_name": request_value
                }
            }
        - With only request value:
            {
                "component*command": request_value
            }
        - With request value as a dictionary (multiple parameters):
            {
                "component*command": {
                    "request_name": {
                        "param1": value1,
                        "param2": value2
                    }
                }
            }
        Note:  
            - If only req_name is provided without req_value, the value defaults to an empty string.
            - If req_value is a dictionary with multiple entries, it is nested under req_name.
            - If req_value is a dictionary with a single entry, it is used directly.
                        - If neither req_name nor req_value is provided, the command value
                            defaults to an empty string.
        Parameters:
            comp_name: str
                Name of the component.
            command_name: str
                Name of the command to execute.
            req_name: Optional[str]
                Name of the request parameter. If None, no parameter is included.
            req_value: Optional
                Value of the request parameter. If None, no value is included.
        Returns:
            str: JSON-formatted command message.
        """
        message = {}
        if req_name is None:
            if req_value is not None:
                message = {
                    comp_name + "*" + command_name: req_value
                }
            else:
                message = {
                    comp_name + "*" + command_name: ""
                }
        elif req_name is not None and req_value is not None:
            if isinstance(req_value,dict):
                if len(req_value) == 1:
                    message = {
                        comp_name + "*" + command_name: req_value
                    }
                else:
                    message = {
                        comp_name + "*" + command_name: {
                            req_name: req_value
                        }
                    }
            else:
                message = {
                    comp_name + "*" + command_name: {
                        req_name: req_value
                    }
                }
        return json.dumps(message)
        
