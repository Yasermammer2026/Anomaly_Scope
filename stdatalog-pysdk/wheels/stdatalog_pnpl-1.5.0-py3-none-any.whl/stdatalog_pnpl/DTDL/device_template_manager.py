# ******************************************************************************
# * @attention
# *
# * Copyright (c) 2022 STMicroelectronics.
# * All rights reserved.
# *
# * This software is licensed under terms that can be found in the LICENSE file
# * in the root directory of this software component.
# * If no LICENSE file comes with this software, it is provided AS-IS.
# *
# *
# ******************************************************************************

"""Device Template catalog and model utilities.

This module manages a local device catalog and related DTDL Device Template models.
It supports reading the bundled USB catalog, optionally updating it from a remote
URL, comparing differences, downloading/removing DTDL JSON models, and resolving
DTMI strings to local paths or remote URLs. It also exposes helpers to query
the catalog and to parse a Device Template JSON into typed interface structures
using the `device_template_model` (DTM) types.

Notes
-----
- `DeviceCatalogManager` is implemented as a simple singleton for process-wide
    access. Use `DeviceCatalogManager.get_instance()` to obtain the instance.
- Console messages use colored `print_*` helpers rather than the logging module.
"""

# Generic
import json
import os
import sys
from datetime import datetime
from enum import Enum

# Custom
import requests
from requests.exceptions import ProxyError, RequestException, SSLError
from stdatalog_pnpl.DTDL import device_template_model as DTM


class ComponentType(Enum):
    """Categorization for component kinds referenced by the catalog.

    Values map hardware and logical blocks into sensor/algorithm/actuator/other.
    """

    SENSOR = 0
    ALGORITHM = 1
    OTHER = 2
    ACTUATOR = 3
    NONE = -1


BOARD_MAP = {
    10: 'STEVAL-STWINKT1',
    14: 'STEVAL-STWINBX1',
    18: 'STEVAL-STWINBX1B',
    13: 'STEVAL-MKBOXPRO',
    17: 'STEVAL-MKBOXPROB',
    19: 'STEVAL-MKBOXPROC',
    9: 'STEVAL-STWINKT1B',
    1: 'STEVAL-MKSBOX1V1',
    2: 'STEVAL-PROTEUS1',
    32: 'B-U585I-IOT02A',
    48: 'NUCLEO-H7A3ZI-Q',
    16: 'NUCLEO-U575ZI-Q',
    127: 'NUCLEO-STM32F401RE',
    126: 'NUCLEO-STM32L476RG',
    51: 'NUCLEO-G0B1RE',
    49: 'NUCLEO-H503RB',
    50: 'NUCLEO-H563ZI',
    98: 'NUCLEO-U385RG-Q',
    97: 'NUCLEO-U545RE-Q',
    64: 'STEVAL-AFCI1',
    33: 'STEVAL-NBIOTV1',
}

DEV_FLAG = False  # Set to True for development/testing, False for production

if DEV_FLAG:
    # Development URL to be used for RC testing purposes
    DEFAULT_DTDL_BASE_URL = 'https://raw.githubusercontent.com/SW-Platforms/appconfig/refs/heads/release/'
    DEFAULT_CATALOG_URL = DEFAULT_DTDL_BASE_URL + 'usb/catalog.json'
else:
    # Production URL to be used for final release
    DEFAULT_DTDL_BASE_URL = (
        'https://raw.githubusercontent.com/STMicroelectronics/appconfig/refs/heads/stdatalog-pysdk_1.5.0/'
    )
    DEFAULT_CATALOG_URL = DEFAULT_DTDL_BASE_URL + 'usb/catalog.json'

LOCAL_DEVICE_CATALOG_PATH = os.path.join(os.path.dirname(sys.modules[__name__].__file__), 'usb_device_catalog.json')


def generate_datetime_string():
    """Return a timestamp string with millisecond resolution.

    Returns:
    - str: formatted as ``YYYY-MM-DD HH:MM:SS,mmm``.
    """
    now = datetime.now()
    datetime_string = now.strftime('%Y-%m-%d %H:%M:%S,%f')[:-3]
    return datetime_string


def print_error(text):
    """Print a red-colored error message to stdout.

    Parameters:
    - text: str message to print.
    """
    print(f'\033[31m{text}\033[0m')


def print_warning(text):
    """Print a yellow-colored warning message to stdout.

    Parameters:
    - text: str message to print.
    """
    print(f'\033[33m{text}\033[0m')


class DeviceCatalogEntry:
    """Lightweight record for a catalog entry.

    Parameters:
    - board_id: int or hex-string, board identifier.
    - fw_id: int or hex-string, firmware identifier.
    - protocol: str protocol name (e.g., 'usb').
    - board_name: str human-readable board label.
    - fw_name: str firmware label.
    - fw_desc: str firmware description.
    - fw_version: str semantic version string.
    - fw_page_url: str URL to the firmware info page.
    - dtmi: str DTMI identifier or empty when absent.
    - fw_bin_url: str URL to the firmware binary, if present.
    - baudrate: int | None optional baudrate for serial-like protocols.
    """

    def __init__(
        self,
        board_id,
        fw_id,
        protocol,
        board_name,
        fw_name,
        fw_desc,
        fw_version,
        fw_page_url,
        dtmi,
        fw_bin_url,
        baudrate=None,
        dtdl_base_url=DEFAULT_DTDL_BASE_URL,
    ):

        self.board_id: int = board_id
        self.fw_id: int = fw_id
        self.protocol = protocol
        self.board_name = board_name
        self.fw_name = fw_name
        self.fw_desc = fw_desc
        self.fw_version = fw_version
        self.fw_page_url = fw_page_url
        self.dtmi = dtmi
        if self.dtmi:
            self.dtmi_local_path = DeviceCatalogManager.get_path_from_dtmi(dtmi)
            self.dtmi_url = DeviceCatalogManager.get_url_from_dtmi(dtmi, dtdl_base_url)
        else:
            self.dtmi_local_path = None
            self.dtmi_url = None
        self.fw_bin_url = fw_bin_url

        self.baudrate = baudrate

    def __repr__(self):
        """Return a concise representation for debug prints."""
        return (
            f'DeviceCatalogEntry(board_id={self.board_id}, fw_id={self.fw_id}, '
            f'protocol={self.protocol}, board_name={self.board_name}, '
            f'fw_name={self.fw_name}, fw_desc={self.fw_desc}, fw_version={self.fw_version}, '
            f'fw_page_url={self.fw_page_url} dtmi={self.dtmi}, '
            f'dtmi_path={self.dtmi_local_path}, dtmi_url={self.dtmi_url}, '
            f'fw_bin_url={self.fw_bin_url})'
        )


class DeviceCatalogManager:
    """Singleton service managing the device catalog and DTDL artifacts.

    Responsibilities:
    - Load the local catalog JSON and expose structured entries.
    - Optionally update the catalog from an online source and persist it.
    - Compute differences between local and online catalogs.
    - Download and remove DTDL model JSONs for entries.
    - Resolve DTMI strings to local storage paths and remote URLs.
    """

    _instance = None  # Static variable to hold the singleton instance

    @staticmethod
    def get_instance(dtdl_base_url=None):
        """
        Static method to get the singleton instance of DeviceCatalogManager.
        If the instance does not exist, it initializes it.

        Returns:
        - DeviceCatalogManager: process-wide singleton instance.
        """
        if DeviceCatalogManager._instance is None:
            DeviceCatalogManager._instance = DeviceCatalogManager._initialize(dtdl_base_url or DEFAULT_DTDL_BASE_URL)
        elif dtdl_base_url is not None and DeviceCatalogManager._instance.dtdl_base_url != dtdl_base_url:
            DeviceCatalogManager._instance = DeviceCatalogManager._initialize(dtdl_base_url)
        return DeviceCatalogManager._instance

    @staticmethod
    def _initialize(dtdl_base_url=DEFAULT_DTDL_BASE_URL):
        """Private static method used to construct the singleton instance.

        Returns:
        - DeviceCatalogManager: an initialized instance with catalog loaded.
        """
        instance = DeviceCatalogManager.__new__(DeviceCatalogManager)  # Create a new instance
        instance.catalog_dict = {}
        instance.catalog_info = {}
        instance.new_catalog_flag = False

        instance.catalog_entries = []
        instance.dev_mode = True  # Set the development mode flag
        instance.proxies = None  # Initialize proxies to None
        instance.dtdl_base_url = dtdl_base_url

        # Load the catalog
        with open(LOCAL_DEVICE_CATALOG_PATH, 'r', encoding='utf-8') as catalog:
            catalog_dict = json.load(catalog)
            if 'usb' in catalog_dict:
                instance.catalog_dict = catalog_dict.get('usb')
                instance.new_catalog_flag = True
            else:
                instance.catalog_dict = catalog_dict
            instance.catalog_info = {
                'date': catalog_dict.get('date', '1970-01-01T00:00:00.000000'),
                'version': catalog_dict.get('version', '0.0.0'),
                'checksum': catalog_dict.get('checksum', '00000000000000000000000000000000'),
            }
            instance.catalog_entries = [
                DeviceCatalogEntry(
                    board_id=(
                        int(entry.get('board_id'), 16)
                        if entry.get('board_id') not in ('', None) and isinstance(entry.get('board_id'), str)
                        else entry.get('board_id')
                    ),
                    fw_id=(
                        int(entry.get('usb_fw_id'), 16)
                        if entry.get('usb_fw_id') not in ('', None) and isinstance(entry.get('usb_fw_id'), str)
                        else entry.get('usb_fw_id')
                    ),
                    protocol=entry.get('protocol'),
                    board_name=entry.get(
                        'brd_name',
                        (
                            BOARD_MAP.get(entry.get('board_id'), 16)
                            if entry.get('board_id') not in ('', None) and isinstance(entry.get('board_id'), str)
                            else entry.get('board_id')
                        ),
                    ),
                    fw_name=entry.get('fw_name', 'no_name'),
                    fw_desc=entry.get('fw_desc', ''),
                    fw_version=entry.get('fw_version', 'no_version'),
                    fw_page_url=entry.get('fw_page_url', ''),
                    dtmi=entry.get('dtmi', ''),
                    fw_bin_url=entry.get('dwn_url', ''),
                    baudrate=entry.get('baudrate', None),
                    dtdl_base_url=instance.dtdl_base_url,
                )
                for entry in instance.catalog_dict
            ]
        return instance

    @staticmethod
    def set_proxies_config(proxies):
        """
        Sets the proxies configuration for requests.

        Args:
            proxies (dict): A dictionary of proxies to use for the requests. e.g., {'http': 'http://proxy.com:8080', 'https': 'http://proxy.com:8080'}.
        """
        # Access the singleton instance of DeviceCatalogManager
        instance = DeviceCatalogManager.get_instance()
        instance.proxies = proxies

    @staticmethod
    def is_dev_mode():
        """
        Returns the development mode flag.
        """
        # Access the singleton instance of DeviceCatalogManager
        instance = DeviceCatalogManager.get_instance()
        return instance.dev_mode

    @staticmethod
    def get_board_names_list():
        """Return the set of unique board names present in the catalog.

        Returns:
        - set[str]: unique board names.
        """
        # Access the singleton instance of DeviceCatalogManager
        instance = DeviceCatalogManager.get_instance()
        # Access the catalog_entries attribute
        catalog_entries = instance.catalog_entries

        # Extract unique board names from catalog_entries
        unique_board_names = {entry.board_name for entry in catalog_entries}
        return unique_board_names

    @staticmethod
    def get_boards_list():
        """Return a list of boards (unique by id) with id and name.

        Returns:
        - list[dict]: each with keys ``board_id`` and ``board_name``.
        """
        # Access the singleton instance of DeviceCatalogManager
        instance = DeviceCatalogManager.get_instance()
        # Access the catalog_entries attribute
        catalog_entries = instance.catalog_entries

        board_list = {
            entry.board_id: {'board_id': entry.board_id, 'board_name': entry.board_name} for entry in catalog_entries
        }
        return list(board_list.values())

    @staticmethod
    def get_firmwares_list(board_identifier):
        """Return firmware name/version list for a given board.

        Parameters:
        - board_identifier: str board name or int board id.

        Returns:
        - list[dict]: entries with ``fw_name`` and ``fw_version``.
        """
        # Access the singleton instance of DeviceCatalogManager
        instance = DeviceCatalogManager.get_instance()
        # Access the catalog_entries attribute
        catalog_entries = instance.catalog_entries
        if isinstance(board_identifier, str):
            # Handle the case where the identifier is a board name
            firmware_list = [
                {
                    'fw_id': entry.fw_id,
                    'fw_name': entry.fw_name,
                    'fw_desc': entry.fw_desc,
                    'fw_version': entry.fw_version,
                    'fw_page_url': entry.fw_page_url,
                    'protocol': entry.protocol,
                    'baudrate': entry.baudrate,
                }
                for entry in catalog_entries
                if entry.board_name == board_identifier
            ]
        elif isinstance(board_identifier, int):
            # Handle the case where the identifier is a board ID
            firmware_list = [
                {
                    'fw_id': entry.fw_id,
                    'fw_name': entry.fw_name,
                    'fw_desc': entry.fw_desc,
                    'fw_version': entry.fw_version,
                    'fw_page_url': entry.fw_page_url,
                    'protocol': entry.protocol,
                    'baudrate': entry.baudrate,
                }
                for entry in catalog_entries
                if entry.board_id == board_identifier
            ]
        else:
            raise TypeError('board_identifier must be either a string (board name) or an integer (board ID)')
        return firmware_list

    @staticmethod
    def get_device_model(board_id, fw_id):
        """
        Searches the catalog for an entry matching the given board_id and fw_id,
        and returns the corresponding dtmi.

        Args:
            board_id (int): The board ID to search for.
            fw_id (int): The firmware ID to search for.

        Returns:
            str: The dtmi if found, otherwise None.
        """
        # Access the singleton instance of DeviceCatalogManager
        instance = DeviceCatalogManager.get_instance()
        # Access the catalog_dict attribute
        catalog_entries = instance.catalog_entries
        for entry in catalog_entries:
            if entry.board_id == board_id and entry.fw_id == fw_id:
                dtdl_json_path = os.path.join(os.path.dirname(sys.modules[__name__].__file__), entry.dtmi_local_path)
                if not os.path.exists(dtdl_json_path):
                    # If the file does not exist, download it from the URL and return the content
                    DeviceCatalogManager.download_dtdl_model_from_url(entry.dtmi_url, dtdl_json_path)
                with open(dtdl_json_path, 'r', encoding='utf-8') as device_model:
                    return json.load(device_model)
        return None

    @staticmethod
    def get_catalog_entry(board_id, fw_id) -> DeviceCatalogEntry:
        """
        Searches the catalog for an entry matching the given board_id and fw_id,
        and returns the corresponding DeviceCatalogEntry.

        Args:
            board_id (int): The board ID to search for.
            fw_id (int): The firmware ID to search for.

        Returns:
            DeviceCatalogEntry: The matching entry if found, otherwise None.
        """
        # Access the singleton instance of DeviceCatalogManager
        instance = DeviceCatalogManager.get_instance()
        # Access the catalog_entries attribute
        catalog_entries = instance.catalog_entries
        for entry in catalog_entries:
            if entry.board_id == board_id and entry.fw_id == fw_id:
                return entry
        return None

    @staticmethod
    def get_component_interface(board_id, fw_id, comp_name):
        """
        Optimized lookup of a component interface by component name.
        Returns the interface dict or None.
        """
        device_model = DeviceCatalogManager.get_device_model(board_id, fw_id)
        if not device_model:
            return None

        catalog_entry = DeviceCatalogManager.get_catalog_entry(board_id, fw_id)
        if not catalog_entry or not catalog_entry.dtmi:
            return None

        root_dtmi = catalog_entry.dtmi

        # Build id map once
        id_map = {}
        for item in device_model:
            _id = item.get('@id')
            if _id:
                id_map[_id] = item

        root_iface = id_map.get(root_dtmi)
        if not root_iface:
            return None

        contents = root_iface.get('contents', [])
        comp_interface_id = None
        for content in contents:
            if content.get('name') == comp_name and content.get('@type') == 'Component':
                # DTDL Component uses 'schema' to reference the interface
                comp_interface_id = content.get('schema')
                break

        if not comp_interface_id:
            return None

        return id_map.get(comp_interface_id)

    @staticmethod
    def compare_catalogs(local_catalog_dict, online_catalog_usb):
        """
        Compares the local catalog dictionary with the online catalog's USB data.

        Args:
            local_catalog_dict (list): The local catalog dictionary (list of entries).
            online_catalog_usb (list): The online catalog's USB data (list of entries).

        Returns:
            dict: A dictionary containing added, removed, and modified entries.
        """
        added = []
        removed = []
        modified = []

        # Convert entries to dictionaries indexed by a unique key (e.g., board_id + fw_id)
        def create_key(entry):
            def to_int(val):
                if val in (None, ''):
                    return -1
                if isinstance(val, int):
                    return val
                if isinstance(val, str):
                    try:
                        return int(val, 16)
                    except ValueError:
                        try:
                            return int(val)
                        except ValueError:
                            return -1
                return -1

            board_id = to_int(entry.get('board_id'))
            fw_id = to_int(entry.get('usb_fw_id', entry.get('fw_id')))
            return f'{board_id}_{fw_id}'

        local_dict = {create_key(entry): entry for entry in local_catalog_dict}
        online_dict = {create_key(entry): entry for entry in online_catalog_usb}

        # Check for added and modified entries
        for key, online_entry in online_dict.items():
            if key not in local_dict:
                added.append(online_entry)
            else:
                local_entry = local_dict[key]

                # Ignore identity fields when comparing (board_id, usb_fw_id, fw_id)
                def _strip_ids(d: dict):
                    return {k: v for k, v in d.items() if k not in ('board_id', 'usb_fw_id', 'fw_id')}

                if _strip_ids(local_entry) != _strip_ids(online_entry):
                    modified.append({'local': local_entry, 'online': online_entry})

        # Check for removed entries
        for key, local_entry in local_dict.items():
            if key not in online_dict:
                removed.append(local_entry)

        return {
            'added': added,
            'removed': removed,
            'modified': modified,
        }

    @staticmethod
    def update_catalog(url=DEFAULT_CATALOG_URL, dtdl_base_url=None):
        """
        Updates the catalog by fetching the latest version from the given URL.
        If the fetch is successful, it updates the local catalog file.

        Parameters:
        - url: The URL to fetch the latest catalog from.
        - dtdl_base_url: The base URL used to resolve DTDL models.
        """

        # Access the singleton instance of DeviceCatalogManager
        instance = DeviceCatalogManager.get_instance(dtdl_base_url)
        # Access the catalog_dict attribute
        local_catalog_dict = instance.catalog_dict
        # Access the catalog_info attribute
        local_catalog_info = instance.catalog_info

        try:
            response = requests.get(url, timeout=10, proxies=instance.proxies)

            catalog_data = response.json()
            date = catalog_data.get('date')
            version = catalog_data.get('version')
            checksum = catalog_data.get('checksum')

            online_catalog_info = {'date': date, 'version': version, 'checksum': checksum}
            local_date = datetime.strptime(local_catalog_info['date'], '%Y-%m-%d %H:%M:%S.%f')
            online_date = datetime.strptime(online_catalog_info['date'], '%Y-%m-%d %H:%M:%S.%f')
            if online_date > local_date:
                print_warning(
                    (
                        f'{generate_datetime_string()} - HSDatalogApp.{__name__} - '
                        f'WARNING - Online catalog date is more recent than '
                        f'local catalog date.'
                    )
                )
                print_warning(
                    (
                        f'{generate_datetime_string()} - HSDatalogApp.{__name__} - '
                        f'WARNING - The local catalog will be updated with the '
                        f'online catalog data.'
                    )
                )
                print_warning(
                    (
                        f'{generate_datetime_string()} - HSDatalogApp.{__name__} - '
                        f'WARNING - The old local catalog json file will be '
                        f'renamed to usb_device_catalog_old.json.'
                    )
                )

                differences = DeviceCatalogManager.compare_catalogs(local_catalog_dict, catalog_data['usb'])
                print('Added entries:', differences['added'])
                print('Removed entries:', differences['removed'])
                print('Modified entries:', differences['modified'])

                if len(differences['added']) > 0:
                    # Print the "dtmi" field for added entries
                    for entry in differences['added']:
                        if 'dtmi' in entry and entry['dtmi']:
                            print(f'Added DTMI: {entry["dtmi"]}')
                            # print(f"URL: {DeviceCatalogManager.get_url_from_dtmi(entry['dtmi'])}")
                            DeviceCatalogManager.download_dtdl_model_from_url(
                                DeviceCatalogManager.get_url_from_dtmi(entry['dtmi'], instance.dtdl_base_url),
                                os.path.join(
                                    os.path.dirname(sys.modules[__name__].__file__),
                                    DeviceCatalogManager.get_path_from_dtmi(entry['dtmi']),
                                ),
                            )

                if len(differences['removed']) > 0:
                    # Print the "dtmi" field for removed entries
                    for entry in differences['removed']:
                        if 'dtmi' in entry and entry['dtmi']:
                            print(f'Removed DTMI: {entry["dtmi"]}')
                            # print(f"URL: {DeviceCatalogManager.get_url_from_dtmi(entry['dtmi'])}")
                            DeviceCatalogManager.remove_dtdl_model_from_local_catalog(
                                entry['board_id'], entry['usb_fw_id']
                            )

                if len(differences['modified']) > 0:
                    # Print the "dtmi" field for modified entries
                    for entry in differences['modified']:
                        if 'dtmi' in entry['online'] and entry['online']['dtmi']:
                            print(f'Modified DTMI: {entry["online"]["dtmi"]}')
                            DeviceCatalogManager.download_dtdl_model_from_url(
                                DeviceCatalogManager.get_url_from_dtmi(entry['online']['dtmi'], instance.dtdl_base_url),
                                os.path.join(
                                    os.path.dirname(sys.modules[__name__].__file__),
                                    DeviceCatalogManager.get_path_from_dtmi(entry['online']['dtmi']),
                                ),
                            )

                # Second check (to address any corner cases. e.g. if the user deleted some dtmi files manually)
                # Ensure all the dtmi files in the local catalog are present, if not download them.
                for entry in local_catalog_dict:
                    if 'dtmi' in entry and entry['dtmi']:
                        dtmi_path = os.path.join(
                            os.path.dirname(sys.modules[__name__].__file__),
                            DeviceCatalogManager.get_path_from_dtmi(entry['dtmi']),
                        )
                        if not os.path.exists(dtmi_path):
                            print(f'DTMI file not found: {dtmi_path}')
                            DeviceCatalogManager.download_dtdl_model_from_url(
                                DeviceCatalogManager.get_url_from_dtmi(entry['dtmi'], instance.dtdl_base_url),
                                dtmi_path,
                            )

                usb_device_catalog_bkp_path = os.path.join(
                    os.path.dirname(sys.modules[__name__].__file__), 'usb_device_catalog_bkp.json'
                )

                # Check if a backup file already exists and remove it
                if os.path.exists(usb_device_catalog_bkp_path):
                    os.remove(usb_device_catalog_bkp_path)  # Remove the existing backup file

                # Rename the current catalog file to a backup file
                os.rename(LOCAL_DEVICE_CATALOG_PATH, usb_device_catalog_bkp_path)

                # Retrieve the custom dtmi entries added by the user from the local catalog
                custom_dtmi_entries = [
                    entry for entry in local_catalog_dict if 'custom_dtmi' in entry and entry['custom_dtmi']
                ]

                # Update the local catalog with the online catalog data
                # (maintaining the custom dtmi entries)
                with open(LOCAL_DEVICE_CATALOG_PATH, 'w', encoding='utf-8') as catalog:
                    # Add the custom dtmi entries to the online catalog data
                    catalog_data['usb'].extend(custom_dtmi_entries)
                    # Save the updated catalog data to the local catalog file
                    json.dump(catalog_data, catalog, indent=4)

                # Update the catalog_dict and catalog_info attributes of the instance
                DeviceCatalogManager._instance = DeviceCatalogManager._initialize(instance.dtdl_base_url)

                print(
                    (
                        f'{generate_datetime_string()} - HSDatalogApp.{__name__} - '
                        f'INFO - Local catalog updated with online catalog data.'
                    )
                )
            else:
                print(
                    (
                        f'{generate_datetime_string()} - HSDatalogApp.{__name__} - '
                        f'INFO - Online catalog data matches local catalog data.'
                    )
                )
            print(
                (
                    f'{generate_datetime_string()} - HSDatalogApp.{__name__} - INFO - '
                    f'Date: {date}, Version: {version}, Checksum: {checksum}'
                )
            )
        except json.JSONDecodeError:
            print_error(
                f'{generate_datetime_string()} - HSDatalogApp.{__name__} - '
                f'ERROR - Invalid JSON response from URL: {url}'
            )
        except (ProxyError, SSLError, RequestException) as e:
            print_warning(f'Network error while trying to fetch the catalog from {url}')
            # Provide more context when proxy is likely involved
            if (
                os.environ.get('HTTP_PROXY')
                or os.environ.get('HTTPS_PROXY')
                or os.environ.get('http_proxy')
                or os.environ.get('https_proxy')
            ):
                print_warning('A proxy is configured; check credentials and certificate trust.')
            print_warning('Impossible to update the catalog. Local catalog will be used instead.')

    @staticmethod
    def download_dtdl_model_from_url(url, save_path):
        """
        Downloads a DTDL model from the given URL and saves it to the specified path.

        Args:
            url (str): The URL to download the DTDL model from.
            save_path (str): The path to save the downloaded DTDL model.

        Returns:
            bool: True if the download was successful, False otherwise.
        """
        # Access the singleton instance of DeviceCatalogManager
        instance = DeviceCatalogManager.get_instance()

        try:
            response = requests.get(url, timeout=15, proxies=instance.proxies)
            if response.status_code == 200:
                # Parse the JSON content
                json_content = response.json()
                # Ensure the directory exists before saving the JSON content to a file
                os.makedirs(os.path.dirname(save_path), exist_ok=True)
                with open(save_path, 'w', encoding='utf-8') as json_file:
                    json.dump(json_content, json_file, indent=4)
                print(
                    (
                        f'{generate_datetime_string()} - HSDatalogApp.{__name__} - '
                        f'INFO - Downloaded DTDL model from {url} and saved to '
                        f'{save_path}.'
                    )
                )
                return True
            else:
                print_error(
                    (
                        f'{generate_datetime_string()} - HSDatalogApp.{__name__} - '
                        f'ERROR - Failed to download DTDL model from {url}. '
                        f'Status code: {response.status_code}'
                    )
                )
                return False
        except (ProxyError, SSLError, RequestException) as e:
            print_error(
                f'{generate_datetime_string()} - HSDatalogApp.{__name__} - ERROR - Network/Proxy error while downloading DTDL model: {e}'
            )
            return False
        except Exception as e:
            print_error(
                (
                    f'{generate_datetime_string()} - HSDatalogApp.{__name__} - '
                    f'ERROR - Exception occurred while downloading DTDL model: {e}'
                )
            )
            return False

    @staticmethod
    def remove_dtdl_model_from_local_catalog(board_id, fw_id):
        """
        Removes the DTDL model from the local catalog for the specified board_id and fw_id.

        Parameters:
        - board_id: The board ID as an integer.
        - fw_id: The firmware ID as an integer.
        """
        # Access the singleton instance of DeviceCatalogManager
        instance = DeviceCatalogManager.get_instance()
        # Access the catalog_dict attribute
        catalog_dict = instance.catalog_dict

        # for each entry in the catalog_dict, check if the board_id and fw_id match
        # and remove the catalog entry and device model json file if it exists
        for entry in catalog_dict:
            if entry['board_id'] == board_id and entry.get('fw_id', entry.get('usb_fw_id')) == fw_id:
                target_file_path = os.path.join(
                    os.path.dirname(LOCAL_DEVICE_CATALOG_PATH),
                    DeviceCatalogManager.get_path_from_dtmi(entry['dtmi']),
                )
                if os.path.exists(target_file_path):
                    os.remove(target_file_path)
                catalog_dict.remove(entry)

        # Save the updated catalog_dict back to the catalog file
        with open(LOCAL_DEVICE_CATALOG_PATH, 'w', encoding='utf-8') as catalog:
            catalog_json = {
                'usb': catalog_dict,
                'date': instance.catalog_info['date'],
                'version': instance.catalog_info['version'],
                'checksum': instance.catalog_info['checksum'],
            }
            json.dump(catalog_json, catalog, indent=4)

    @staticmethod
    def get_path_from_dtmi(dtmi_string):
        """
        Creates a path from the given DTMI string by replacing ':' with the
        appropriate path separator, replacing the last ';' with a '-', and
        adding a '.json' postfix.

        Parameters:
        - dtmi_string: The DTMI string.

        Returns:
        - The created path as a string.
        """
        if not dtmi_string.startswith('dtmi:'):
            raise ValueError('Invalid DTMI string format')

        # Replace ':' with the appropriate path separator
        dtmi_path = dtmi_string.replace(':', os.sep)

        # Replace the last ';' with a '-'
        dtmi_path = dtmi_path.replace(';', '-', 1)

        # Add the '.json' postfix
        dtmi_path += '.json'

        return dtmi_path

    @staticmethod
    def get_url_from_dtmi(dtmi_string, dtdl_base_url=DEFAULT_DTDL_BASE_URL):
        """
        Converts a DTMI string into a URL pointing to the corresponding expanded JSON file.

        Args:
            dtmi_string (str): The DTMI string.

        Returns:
            str: The URL pointing to the expanded JSON file.
        """
        if not dtmi_string.startswith('dtmi:'):
            raise ValueError('Invalid DTMI string format')

        # Replace ':' with '/' and the last ';' with '-'
        dtmi_path = dtmi_string.replace(':', '/').replace(';', '-', 1)

        return f'{dtdl_base_url}{dtmi_path}.expanded.json'

    @staticmethod
    def remove_custom_dtdl_model(board_id, fw_id):
        """
        Removes the custom DTDL model for the specified board_id and fw_id from the local catalog.
        If the custom DTDL model file exists, it is deleted from the filesystem.

        Parameters:
        - board_id: The board ID as an integer.
        - fw_id: The firmware ID as an integer.
        """
        # Access the singleton instance of DeviceCatalogManager
        instance = DeviceCatalogManager.get_instance()
        # Access the catalog_dict attribute
        catalog_dict = instance.catalog_dict
        # Access the catalog_info attribute
        catalog_info = instance.catalog_info

        # for each entry in the catalog_dict, check if the board_id and fw_id match
        # and remove the custom dtmi file if it exists
        for entry in catalog_dict:
            if entry['board_id'] == board_id and entry.get('fw_id', entry.get('usb_fw_id')) == fw_id:
                target_file_path = entry['custom_dtmi']
                if os.path.exists(target_file_path):
                    os.remove(target_file_path)
                entry['custom_dtmi'] = ''

        # Save the updated catalog_dict back to the catalog file
        with open(LOCAL_DEVICE_CATALOG_PATH, 'w', encoding='utf-8') as catalog:
            catalog_json = {
                'usb': catalog_dict,
                'date': catalog_info['date'],
                'version': catalog_info['version'],
                'checksum': catalog_info['checksum'],
            }
            json.dump(catalog_json, catalog, indent=4)

    @staticmethod
    def add_dtdl_model(board_id: int, fw_id: int, dtdl_model_name, dtdl_model_json):
        """
        Adds a new DTDL model to the local catalog or updates an existing one.

        Parameters:
        - board_id: The board ID as an integer.
        - fw_id: The firmware ID as an integer.
        - dtdl_model_name: The name of the DTDL model.
        - dtdl_model_json: The JSON content of the DTDL model.
        """

        # Convert board_id and fw_id to hexadecimal string
        board_id = hex(board_id)
        fw_id = hex(fw_id)

        # Access the singleton instance of DeviceCatalogManager
        instance = DeviceCatalogManager.get_instance()
        # Access the catalog_dict attribute
        catalog_dict = instance.catalog_dict
        # Access the catalog_info attribute
        catalog_info = instance.catalog_info

        # Prepare the target folder and file path
        target_folder = os.path.join(os.path.dirname(sys.modules[__name__].__file__), 'dtmi', 'custom')
        target_file_path = os.path.join(target_folder, os.path.basename(dtdl_model_name) + '.json')

        # Check if the entry already exists and update it
        dtm_updated = False
        for entry in catalog_dict:
            # Convert board_id and fw_id to integers if they are in hexadecimal string format
            if entry['board_id'] == board_id and entry['fw_id'] == fw_id:
                entry['custom_dtmi'] = target_file_path
                print(
                    (
                        f'{generate_datetime_string()} - HSDatalogApp.{__name__} - '
                        f'INFO - Local version of existing Device Template '
                        f'Updated [{board_id},{fw_id}]'
                    )
                )
                dtm_updated = True
                break

        # If the entry does not exist, add a new one
        if not dtm_updated:
            new_dtdl = {'board_id': board_id, 'fw_id': fw_id, 'custom_dtmi': target_file_path}
            catalog_dict.append(new_dtdl)
            print(
                (
                    f'{generate_datetime_string()} - HSDatalogApp.{__name__} - INFO - '
                    f'Added new Device Template [{board_id},{fw_id}] '
                    f'{target_file_path}'
                )
            )

        # Ensure the target folder exists
        if not os.path.exists(target_folder):
            os.makedirs(target_folder)

        # Write the DTDL model JSON to the target file
        with open(target_file_path, 'w', encoding='utf-8') as file:
            file.write(dtdl_model_json)

        # Save the updated catalog_dict back to the catalog file
        with open(LOCAL_DEVICE_CATALOG_PATH, 'w', encoding='utf-8') as catalog:
            catalog_json = {
                'usb': catalog_dict,
                'date': catalog_info['date'],
                'version': catalog_info['version'],
                'checksum': catalog_info['checksum'],
            }
            json.dump(catalog_json, catalog, indent=4)

    @staticmethod
    def query_dtdl_model(board_id, fw_id):
        """Return the DTDL model(s) for a board/firmware pair.

        Parameters:
        - board_id: int | str board id (int or hex-string).
        - fw_id: int | str firmware id (int or hex-string).

        Returns:
        - dict | list | object: The parsed JSON model or a dict of them when
            multiple models match.
        """

        # Access the singleton instance of DeviceCatalogManager
        instance = DeviceCatalogManager.get_instance()
        # Access the catalog_dict attribute
        catalog_dict = instance.catalog_dict

        dtdl_model_ids = []
        for entry in catalog_dict:
            if 'board_id' in entry and entry['board_id'] != '':
                entry['board_id'] = (
                    int(entry['board_id'], 16) if isinstance(entry['board_id'], str) else entry['board_id']
                )
            else:
                # Skip the entry if the board_id is not present
                continue
            if 'fw_id' in entry:
                entry['fw_id'] = int(entry['fw_id'], 16) if isinstance(entry['fw_id'], str) else entry['fw_id']
            else:
                entry['usb_fw_id'] = (
                    int(entry['usb_fw_id'], 16) if isinstance(entry['usb_fw_id'], str) else entry['usb_fw_id']
                )
            board_id = int(board_id, 16) if isinstance(board_id, str) else board_id
            fw_id = int(fw_id, 16) if isinstance(fw_id, str) else fw_id
            if entry['board_id'] == board_id and (entry.get('fw_id') == fw_id or entry.get('usb_fw_id') == fw_id):
                if 'custom_dtmi' in entry and entry['custom_dtmi'] != '':
                    print_warning(
                        (
                            f'{generate_datetime_string()} - HSDatalogApp.{__name__} - '
                            f'WARNING - CUSTOM User Device Model selected for '
                            f'(fw_id: {fw_id}, board_id {board_id}).'
                        )
                    )
                    dtdl_model_id = entry['custom_dtmi']
                    dtdl_model_ids.append(dtdl_model_id)
                    print((f'{generate_datetime_string()} - HSDatalogApp.{__name__} - INFO - dtmi: {dtdl_model_id}'))
                elif 'dtmi' in entry and entry['dtmi'] != '':
                    print(
                        (
                            f'{generate_datetime_string()} - HSDatalogApp.{__name__} - '
                            f'INFO - dtmi found in SDK supported models'
                        )
                    )
                    dtdl_model_id = DeviceCatalogManager.get_path_from_dtmi(entry['dtmi'])
                    dtdl_model_ids.append(dtdl_model_id)
                    print((f'{generate_datetime_string()} - HSDatalogApp.{__name__} - INFO - dtmi: {dtdl_model_id}'))
        if len(dtdl_model_ids) == 1:
            dtdl_json_path = os.path.join(os.path.dirname(sys.modules[__name__].__file__), dtdl_model_id)
            with open(dtdl_json_path, 'r', encoding='utf-8') as device_model:
                return json.load(device_model)
        else:
            device_models = {}
            for dtm_id in dtdl_model_ids:
                dtdl_json_path = os.path.join(os.path.dirname(sys.modules[__name__].__file__), dtm_id)
                with open(dtdl_json_path, 'r', encoding='utf-8') as device_model:
                    device_models[dtm_id] = json.load(device_model)
            return device_models
        return ''


class DeviceTemplateManager:
    """Utility to navigate Device Template contents.

    Wraps a DTDL Device Template JSON and exposes helpers to retrieve the root
    interface and its child components, as well as looking up component
    interfaces by name using the DTM typed mapping.
    """

    def __init__(self, device_template_json: dict) -> None:
        """Build a manager from a Device Template JSON object.

        Parameters:
        - device_template_json: dict loaded Device Template JSON content.
        """
        self.device_template_model = device_template_json
        self.interface_list = self.__get_interface_list()

        self.root_component = None
        for interface in self.interface_list:
            if self.__is_root_interface(interface):
                self.root_component = interface
                break

        self.components = {}
        for content in self.root_component.contents:
            if content.type == DTM.ContentType.COMPONENT:
                for interface in self.interface_list:
                    if content.schema == interface.id:
                        self.components[content.name] = interface

        # self.root_component = self.get_root_component()
        # self.components = self.get_components()

    def __get_interface_list(self):
        """Collect and map interface dictionaries into DTM typed objects.

        Returns:
        - list[DTM.InterfaceElement]: parsed interfaces present in the model.
        """
        interfaces = []
        for d in self.device_template_model:
            if 'contents' in d:
                interfaces.append(DTM.InterfaceElement.from_dict(d))
        return interfaces

    def __is_root_interface(self, interface):
        """Return True if the interface represents the root component."""
        return interface.contents[0].type == DTM.ContentType.COMPONENT

    def get_root_component(self):
        """Return the root component interface."""
        return self.root_component

    def get_components(self):
        """Return a mapping of component name to interface element."""
        return self.components

    def get_components_name_list(self):
        """Return a list of component names present in the template."""
        comp_names_list = []
        for c in self.components:
            comp_names_list.append(c.name)
        return comp_names_list

    def get_component(self, comp_name: str):
        """Return the interface element for the specified component name.

        Parameters:
        - comp_name: str component name.

        Returns:
        - DTM.InterfaceElement | None: interface element or None if not found.
        """
        try:
            res = self.components[comp_name]
            return res
        except Exception:
            print_error(
                (
                    f'{generate_datetime_string()} - HSDatalogApp.{__name__} - '
                    f"ERROR - Component '{comp_name}' doesn't exist in your "
                    f'selected Device Template.'
                )
            )
            return None
