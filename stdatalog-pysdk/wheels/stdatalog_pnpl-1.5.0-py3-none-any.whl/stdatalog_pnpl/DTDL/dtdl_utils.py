
# ******************************************************************************
# * @attention
# *
# * Copyright (c) 2022 STMicroelectronics.
# * All rights reserved.
# *
# * This software is licensed under terms that can be found in the LICENSE file
# * in the root directory of this software component.
# * If no LICENSE file comes with this software, it is provided AS-IS.
# *
# *
# ******************************************************************************
"""
DTDL utilities and enums for component classification and visualization.

This module centralizes Device Template Model (DTDL) utilities used across the SDK,
including:
- Well-known component group keys (sensors, algorithms, actuators, other).
- Human-friendly unit mapping for common measurement units.
- Enums for component and algorithm types, graph/widget types, and sensor categories.

The symbols here are referenced by device parsing, UI rendering, and data-processing code.
"""

from enum import Enum

# DTDL component group keys used in device templates
DTDL_SENSORS_ID_COMP_KEY = "sensors"
DTDL_ALGORITHMS_ID_COMP_KEY = "algorithms"
DTDL_ACTUATORS_ID_COMP_KEY = "actuators"
DTDL_OTHER_ID_COMP_KEY = "other"

class UnitMap():
    """Mapping from DTDL unit names to human-readable symbols.

    Use this helper to present compact, user-friendly unit strings in UIs and exports.
    """

    def __init__(self) -> None:
        """Initialize the unit dictionary with common unit conversions.

        The mapping translates DTDL unit names (e.g., "degreeCelsius") to symbols
        (e.g., "°C"). Extend this dictionary if additional units are required.

        Returns
        -------
        None
        """
        self.unit_dict = {
            "gForce":"g",
            "gauss":"G",
            "decibel":"dB",
            "degreePerSecond":"dps",
            "mdps":"mdps",
            "degreeCelsius":"°C",
            "hertz":"Hz",
            "second":"s",
            "Waveform":"Waveform",
            "percent":"%",
            "millisecond":"ms",
            "microsecond":"μs"
        }

class ComponentTypeEnum(Enum):
    """High-level component type classification used in templates and UIs."""
    SENSOR = 0
    ALGORITHM = 1
    ACTUATOR = 3
    OTHER = 2

ALGORITHM_TYPE_STRING = "algorithm_type"

class AlgorithmTypeEnum(Enum):
    """Supported algorithm categories for data processing and analytics."""
    IALGORITHM_TYPE_FFT = 0
    IALGORITHM_TYPE_ANOMALY_DETECTOR = 1
    IALGORITHM_TYPE_CLASSIFIER = 2

ENABLED_STRING = "enabled"          # Generic flag enabling a component/feature
MIN_STRING = "min"                   # Minimum bound for ranges
MAX_STRING = "max"                   # Maximum bound for ranges
UNIT_STRING = "unit"                 # Unit key used with UnitMap
GRAPH_TYPE_STRING = "graph_type"     # UI graph/widget type selector

class GraphTypeEnum(Enum):
    """Graph/widget types supported by visualization layers."""
    LINE = 0
    V_BAR = 1
    H_BAR = 2
    V_LEVEL = 3
    H_LEVEL = 4
    FFT = 5
    GAUGE = 6
    CLASSIFIER = 7
    ANOMALY_DETECT = 8
    LINE_WAV = 9
    PLOT_ARRAY = 10
    LABEL = 11
    CHECKBOX = 12
    UNKWONW = -1

# DatalogMC telemetry utilities and component names
MC_SLOW_TELEMETRY_STRING = "slow_mc_telemetry"
MC_FAST_TELEMETRY_STRING = "fast_mc_telemetry"
MC_SLOW_TELEMETRY_COMP_NAME = "slow_mc_telemetries"
MC_FAST_TELEMETRY_COMP_NAME = "fast_mc_telemetries"
MC_FAST_TELEMETRY_SENSITIVITY = "sensitivity"
AI_CLASSIFIER_COMP_NAME = "ai_motor_classifier"

ST_BLE_STREAM = "st_ble_stream"

class SensorCategoryEnum(Enum):
    """Sensor categories used to specialize behavior and decoding paths."""
    ISENSOR_CLASS_MEMS = 0
    ISENSOR_CLASS_AUDIO = 1
    ISENSOR_CLASS_RANGING = 2
    ISENSOR_CLASS_LIGHT = 3
    ISENSOR_CLASS_CAMERA = 4
    ISENSOR_CLASS_PRESENCE = 5
    ISENSOR_CLASS_POWERMETER = 6
